
#ifndef _VA_LIST_H
#define _VA_LIST_H
typedef unsigned char *va_list;
#endif