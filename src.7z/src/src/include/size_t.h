
typedef unsigned size_t;