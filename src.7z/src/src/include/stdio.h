
int geti();
char getc();