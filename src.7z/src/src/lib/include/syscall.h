
int getpid(void);
int getppid(void);
int kfork();
int fork();
int wait();
int wakeup(int);
int sleep(int);
int exit();
int stop(int);
int continu();
int chpri();
int tswitch();
int lock();
char getc();
int getcs();
int geti();
int printf(const char *fmt, ...);