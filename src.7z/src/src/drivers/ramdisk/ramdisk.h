

void readSectorRmdsk(unsigned int sector, unsigned char *buf);
void writeSectorRmdsk(unsigned int sector, unsigned char *buf);