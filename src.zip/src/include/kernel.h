
#define SSIZE 1024
#define NPROC 4

typedef struct proc 
{
    struct proc* next;
    int *kesp;
    int pid;							// process ID number
    int ppid;							// parent ID process
    int event;							// sleep event 
    int status;							// state process = FREE|READY|STOP|DEAD|RUNNING|ZOMBIE
    struct proc* parent;						// pointer to parent process
    int priority;
    int exitCode;						// exit code
    int kstack[SSIZE];					// stack kernel of the process
} __attribute__ ((packed)) proc;


#ifdef SCHED
#define FREE	0
#define READY	1
#define STOP	2
#define DEAD	3
#define SLEEP	4
#define ZOMBIE	5
#endif
#ifdef LIST
proc* get_proc(proc**);					// return a FREE process pointer from list
int put_proc(proc**, proc*);			// Enter process pointer into list
int enqueue(proc**, proc*);				// Enter process pointer into queue by priority
proc* dequeue(proc**);					// return first process pointer remove from queue
proc *kfork();
int kexit (int);
int kstop ();
int kwakeup (int);
int ksleep (int);
int kwait (int*);
int kcontinue ();
int changePriority(int, int);
#endif
#ifdef PROC
int numproc;

proc process[NPROC], *running, *readyQueue, *freeQueue, *sleepQueue;
#else
extern proc process[NPROC],*running,*running, *readyQueue, *freeQueue, *sleepQueue;
#endif
void do_tswitch(void);
int do_fork();
void do_exit();
void do_stop(int);
void do_continue(int);
void do_sleep(int);
void do_wakeup(int);
void do_changePriority();
int kprintf(const char *fmt, ...);
int geti();
char getc();
void init();
void printList (proc* list);
int scheduler();