#ifndef _INTR_H
#define _INTR_H
#ifdef I8259A
#define	I8259A_PORTA0	0x20
#define	I8259A_PORTB0	0x21
#define	I8259A_PORTA1	0xA0
#define	I8259A_PORTB1	0xA1
#endif
void map_i386_mask_irq(void);
void map_i386_irq(void);
void map_i386_active_irq(void);
#endif