

int kprintf(unsigned char *fmt, ...);