#define LIST
#define SCHED
#include "../include/kernel.h"

extern void tswitch(void);
int rflag = 0;
// schedule ready process list
int scheduler(){
	kprintf("end running -> %d\n", running->pid);
	if(running->status == READY)
    	enqueue(&readyQueue, running);
    running = dequeue(&readyQueue);
    kprintf("new running -> %d\n", running->pid);
}
// reschedule ready process list if rflag is 1
int reschedule(){
	proc* p, *tmp = 0;
	while( p = dequeue(&readyQueue) ){
		enqueue(&tmp, p);
	}
	readyQueue = tmp;
	rflag = 0;
	if(running->priority < readyQueue->priority)
		rflag = 1;
}
// change priority of a process
int changePriority(int pid, int priority){
	proc* p; int ok=0, req=0;
	if(pid == running->pid){
		running->priority = priority;
		if(priority < readyQueue->priority)
			rflag = 1;
		return 1;
	}
	for(int i = 0;i<NPROC; i++){
		p = &process[i];
		if(p->pid == pid && p->status != FREE){
			p->priority = priority;
			ok = 1;
			if(p->status == READY)
				req = 1;
		}
	}
	if(!ok){
		kprintf("changePriority failed\n");
		return -1;
	}
	if(req)
		reschedule();

}

void do_changePriority(){
	int pid, priority;
	kprintf("input pid: ");
	pid = geti();
	kprintf(" input new priority ");
	priority = geti();
	if(priority<1)
		priority = 1;
	changePriority(pid, priority);

}

void do_tswitch(){
    tswitch();
}


int do_fork(){
	proc* p = kfork();
	if(!p){
		kprintf("kfork failed \n");
		return -1;
	}
	return p->pid;
}

void do_exit(){
	kexit(0);
}

void do_stop(int pid){
	proc* p;
	if(!pid)
		p = running;
	for (int i = 0; i < NPROC; ++i)
	{
		if(i == pid)
			p = &process[i];
	}
	kstop(p->pid);
}

void do_continue(int pid){
	kcontinue(pid);
}
