#define LIST
#define SCHED
#define PROC

#include "../include/kernel.h"
#include "../include/string.h"
#include "../include/con.h"

int procSize = sizeof(proc);

void printList (proc* list){
	for(proc* j = list;j;j=j->next)
    	if(j == list)
    		kprintf("P%d ",j->pid);
    	else
    		kprintf("-> P%d ",j->pid);
    kprintf("\n");
}

int body(){
	char c;
    kprintf("proc %d start from body \n", running->pid);
    while(1){
    	setColorText(running->pid+1);

    	kprintf("freeQueue : ");printList(freeQueue);
    	kprintf("readyQueue : ");printList(readyQueue);
        kprintf("proc %d running: parent %d \n", running->pid, running->ppid);
        kprintf(" do action number ");
        c = getc();
        switch(c){
        	case 0xe:
				kprintf("do_fork\n");
				do_fork();
				break;
			case 0xf:
				kprintf("do_tswitch\n");
				do_tswitch();
				break;
			default:
				kprintf("\n");
				break;
        }
    }
    return 0;
}

proc* kfork(){
	int i;
	proc* p = get_proc(&freeQueue);							// get a new process from free process
	if(!p){
		kprintf("no more PROCESS, kfork() aborted.");
		return 0;
	}
	p->status = READY;										// set process as ready
	p->priority = 1;										// set child's process priority to 1
	p->ppid = running->pid;									// set parent process
	for(i = 1;i<10;i++)
		p->kstack[SSIZE-i] = 0;								// initialize the stack
	p->kstack[SSIZE-1] = (int) &body;						// set eip address return [=> body] from stack 
	p->kesp = &p->kstack[SSIZE-9];							// process save esp
	kprintf("init complet body point to %p\n",&body);
	enqueue(&readyQueue, p);								// enter p into readyQueue by priority
	return p;
}

int kexit (int e){
	proc*p; int wakeupp1 = 0;
	if(!running->pid == 1 && numproc > 2)
		return -1;
	for(int i = 1; i<NPROC;i++){
		p = &process[i];
		if(p->status != FREE && p->ppid == running->pid){
			p->ppid = 1;
			p->parent = &process[1];
			wakeupp1++;
		}
	}
	running->exitCode = e;
	running->status = ZOMBIE;
	kwakeup((int)running->parent);
	if(wakeupp1)
		kwakeup((int)&process[1]);
	kprintf("proc id %d exitCode %d\n", running->pid, running->exitCode);
	tswitch();
}

int kstop (int pid){
	if(!pid)
		return 0;
	process[pid].status = STOP;
	kprintf("proc id %d stop \n", running->pid);
	tswitch();
}

int kcontinue (int pid){
	proc* p;
	for(int i = 0;i<NPROC; i++){
		p = &process[i];
		if(i == pid)
			if(process[i].status == STOP || process[i].status == DEAD){
				process[i].status = READY;
				enqueue(&readyQueue, &process[i]);
				kprintf("proc id %d continue \n", pid);
			}
	}
}

int kwait(int* status){
	proc* p; int hasChild = 0;
	while(1){
		for(int i=0;i<NPROC;i++){
			p = &process[i];
			if(p->status != FREE && p->ppid == running->pid){
				hasChild = 1;
				if(p->status == ZOMBIE){
					*status = p->exitCode;
					p->status = FREE;
					enqueue(&freeQueue, p);
					numproc--;
					return p->pid;
				}
			}
		}
		if(!hasChild)
			return -1;
		ksleep((int)running);
	}
}

int ksleep(int evt){
	running->event = evt;
	running->status = SLEEP;
	enqueue(&sleepQueue, running);
	kprintf("proc id %d sleep \n", running->pid);
	do_tswitch();
}

int kwakeup(int evt){
	proc* p;
	while(1){
		p = dequeue(&sleepQueue);
		if(!p)
			break;
		else if(p->event == evt){
			p->status = READY;
			p->event = 0;
			dequeue(&sleepQueue);
			enqueue(&readyQueue, p);
			kprintf("proc id %d wakeup \n", p->pid);
		}else
			enqueue(&freeQueue, p);
	}
}

proc* getrunning(){
    return running;
}

void init(){
    proc *p;
    int i;
    kprintf("init ....\n");
    for(i=0;i<NPROC;i++){									// initialize all process
        p = &process[i];									// 
        p->pid = i;											// set process's pid
        p->status = FREE;									// mark process as FREE
        p->priority = 0;
        if(i<NPROC)									// set process's priority to 0
        	p->next = &process[i+1];
    }
    process[NPROC-1].next = 0;
    freeQueue = &process[0];
    readyQueue = 0;

    /****** create init process as running ****/
    p = get_proc(&freeQueue);
    p->status = READY;										// set init as ready
	p->priority = 0;										// set init priority to 0
	p->ppid = 0;											// init's parent is itself
    running = p;											// init is now ready
}
