#include <stdio.h>

#define RAMDSKLIMIT 0x10000
#define SECTORSIZE 0x200

char ramdisk[RAMDSKLIMIT] = {0,}; // size ramdisk in byte

int read_sector (int sector, char *buf){
	for(int i = 0;i<SECTORSIZE;i++){
		buf[i] = ramdisk[sector*SECTORSIZE+i];
	}

}

int write_sector(int sector, char *buf){
	for(int i = 0;i<SECTORSIZE;i++){
		ramdisk[sector*SECTORSIZE+i] = buf[i];
	}
}

int main(int argc, char**argv){
	// init ramdisk structure
	int nsectors = RAMDSKLIMIT/SECTORSIZE;
	char readbuffer[512] = "";
	char writebuffer[512] = {0,};

}